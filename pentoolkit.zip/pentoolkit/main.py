from modules import port_scanner, banner_grabber, http_header_grabber

def main_menu():
    print("\n=== Pentoolkit Menu ===")
    print("1. Port Scanner")
    print("2. Banner Grabber")
    print("3. HTTP Header Grabber")
    print("4. Exit")
    choice = input("Enter your choice: ")

    if choice == "1":
        port_scanner.run()
    elif choice == "2":
        banner_grabber.run()
    elif choice == "3":
        http_header_grabber.run()
    elif choice == "4":
        print("Exiting...")
        exit()
    else:
        print("Invalid choice. Try again.")

if __name__ == "__main__":
    while True:
        main_menu()
