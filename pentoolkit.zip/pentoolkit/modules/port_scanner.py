import socket 

def scan_all_ports(target):
    print(f"scanning all ports on {target}...")
    for port in range(1, 65536):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.5)
        result = sock.connect_ex((target, port))
        if result ==0:
           print(f"port {port}: OPEN")
        sock.close()
    
def run():
    target_ip = input("Enter target IP: ")
    scan_all_ports(target_ip)
