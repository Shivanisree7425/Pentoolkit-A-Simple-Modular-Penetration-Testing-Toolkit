import requests

def grab_headers(url):
    try:
        response = requests.get(url)
        print(f"Headers for {url}:")
        for header, value in response.headers.items():
            print(f"{header}: {value}")
    except Exception as e:
        print(f"Error: {e}")

def run():
    url = input("Enter URL (e.g., http://example.com): ")
    grab_headers(url)
