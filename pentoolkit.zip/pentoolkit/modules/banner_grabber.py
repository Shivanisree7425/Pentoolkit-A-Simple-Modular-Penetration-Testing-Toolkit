import socket

def grab_banner(ip, port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(3)  # 3-second timeout
        result = sock.connect_ex((ip, port))

        if result != 0:
            print(f"[!] Port {port} on {ip} is closed or unreachable.")
            sock.close()
            return

        # If connected, try grabbing the banner
        try:
            sock.sendall(b"HEAD / HTTP/1.0\r\n\r\n")
            banner = sock.recv(1024).decode(errors="ignore")
            if banner:
                print(f"[+] Banner from {ip}:{port} →\n{banner}")
            else:
                print(f"[!] No banner received from {ip}:{port}.")
        except Exception as e:
            print(f"[!] Error grabbing banner: {e}")
        finally:
            sock.close()

    except Exception as e:
        print(f"[!] Connection error: {e}")

def run():
    ip = input("Enter target IP: ").strip()
    port = int(input("Enter port number: "))
    grab_banner(ip, port)

